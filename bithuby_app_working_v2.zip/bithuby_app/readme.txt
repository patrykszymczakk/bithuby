Kod poprawny z dnia 22.11.2024

Możliwośc logowania się przez uzytkownikow. Mozliwosc rejestracji.
- wymagania żeby użytkownik zalozyl konto i się zalogowal
- dzialajaca storna wyboru kategorii i kraju
- po wyborze dobrze przekierowuje do okna chatu.
- chat dobrze paruje uzytkownikow w pokoju
- po nacisnieciu SKIP jeśli jest dwóch uzytkownikow dobrze paruje uzytkownikow w te same pary

Do rozwiązania:

- okno logowania na stronie głównej do usuniecia
- sprawdzić czy użytkownik moze wejść bezpośrednio bez logowania na localhost/chat.html? 
- nie widać drugiego okna kamery widać tylko jedno okno jeśli robie to w srodowisku testowym na localhoscie uzywajac jednego urządzenia nagrywającego.


