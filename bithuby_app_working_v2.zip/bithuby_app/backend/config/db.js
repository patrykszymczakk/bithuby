const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host: 'localhost',
    user: 'root', // Zmień na swojego użytkownika MySQL
    password: 'Dupa1234.!', // Zmień na swoje hasło MySQL
    database: 'bithuby666', // Zmień na nazwę swojej bazy danych
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
});

module.exports = pool;