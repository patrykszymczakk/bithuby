const express = require('express');
const path = require('path');
const authRoutes = require('./auth/authRoutes');

const app = express();

// Middleware do parsowania JSON
app.use(express.json());

// Middleware dla obsługi CORS
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    next();
});

// Ustawienie folderu `frontend` jako folder statyczny
app.use(express.static(path.join(__dirname, '../frontend')));

// Trasy API
app.use('/auth', authRoutes);

// Obsługa pliku main.html
app.get('/main.html', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/main.html')); // Zaktualizowana ścieżka
});

// Domyślna trasa dla aplikacji frontendowej
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html')); // Zaktualizowana ścieżka
});

// Uruchomienie serwera
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
