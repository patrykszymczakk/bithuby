const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: ['http://localhost:3001', 'http://127.0.0.1:3001'], // Dodaj oba adresy
        methods: ['GET', 'POST']
    }
});

const JWT_SECRET = process.env.JWT_SECRET || '3H@rdT0Gu3$$+53cR3t#K3y!2024';

const rooms = {}; // Tracks users in each room

io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    if (!token) {
        console.log('No token provided');
        return next(new Error('Authentication error'));
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        socket.user = decoded; // Dodanie użytkownika do kontekstu socket
        next();
    } catch (err) {
        console.log('Invalid token:', err.message);
        next(new Error('Authentication error'));
    }
});

io.on('connection', (socket) => {
    console.log(`New user connected: ${socket.id} (User ID: ${socket.user.userId})`);

    socket.on('joinRoom', ({ country, category }) => {
        const roomKey = `${country}-${category}`;
        if (!rooms[roomKey]) {
            rooms[roomKey] = [];
        }

        rooms[roomKey].push(socket.id);
        console.log(`User ${socket.id} joined room: ${roomKey}`);
        console.log(`Current users in room: ${rooms[roomKey]}`);

        const partnerId = rooms[roomKey].find((id) => id !== socket.id);
        if (partnerId) {
            io.to(socket.id).emit('partnerFound', { partnerId });
            io.to(partnerId).emit('partnerFound', { partnerId: socket.id });
            console.log(`User ${socket.id} paired with ${partnerId}`);
        } else {
            console.log(`No partner available for user ${socket.id}`);
        }
    });

    socket.on('signal', ({ target, data }) => {
        console.log(`Signal from ${socket.id} to ${target}`, data);
        io.to(target).emit('signal', { from: socket.id, data });
    });

    socket.on('skip', ({ country, category }) => {
        const roomKey = `${country}-${category}`;
    
        // Sprawdź, czy pokój istnieje
        if (!rooms[roomKey]) {
            console.log(`Room ${roomKey} does not exist for user ${socket.id}`);
            return;
        }
    
        // Usuń użytkownika z pokoju
        rooms[roomKey] = rooms[roomKey].filter(id => id !== socket.id);
        console.log(`User ${socket.id} skipped in room: ${roomKey}`);
    
        // Dodaj użytkownika z powrotem do pokoju
        rooms[roomKey].push(socket.id);
    
        // Znajdź nowego partnera
        const partnerId = rooms[roomKey].find(id => id !== socket.id);
    
        if (partnerId) {
            io.to(socket.id).emit('partnerFound', { partnerId });
            io.to(partnerId).emit('partnerFound', { partnerId: socket.id });
            console.log(`User ${socket.id} paired with ${partnerId} after skip`);
        } else {
            io.to(socket.id).emit('noPartnerAvailable');
            console.log(`No partner available for user ${socket.id} in room: ${roomKey}`);
        }
    });
    

    socket.on('disconnect', () => {
        console.log('User disconnected:', socket.id);
        for (const roomKey in rooms) {
            rooms[roomKey] = rooms[roomKey].filter((id) => id !== socket.id);
            if (rooms[roomKey].length === 0) {
                delete rooms[roomKey];
                console.log(`Room ${roomKey} deleted as it is now empty`);
            }
        }
    });
});

server.listen(4000, () => {
    console.log('Chat server running on http://localhost:4000');
});
