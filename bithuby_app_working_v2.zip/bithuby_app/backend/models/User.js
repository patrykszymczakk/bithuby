const db = require('../config/db');

const User = {
    async findByEmail(email) {
        const [rows] = await db.execute('SELECT * FROM users WHERE email = ?', [email]);
        return rows[0];
    },
    async findById(id) {
        const [rows] = await db.execute('SELECT * FROM users WHERE id = ?', [id]);
        return rows[0];
    },
    async create(username, email, hashedPassword) {
        const [result] = await db.execute(
            'INSERT INTO users (username, email, password, isActive) VALUES (?, ?, ?, ?)',
            [username, email, hashedPassword, false] // Domyślnie `isActive` ustawione na false
        );
        return {
            id: result.insertId,
            username,
            email,
            password: hashedPassword,
            isActive: false,
        };
    },
    async update(id, data) {
        const fields = Object.keys(data).map(key => `${key} = ?`).join(', ');
        const values = Object.values(data);
        values.push(id);
        await db.execute(`UPDATE users SET ${fields} WHERE id = ?`, values);
    },
};

module.exports = User;
