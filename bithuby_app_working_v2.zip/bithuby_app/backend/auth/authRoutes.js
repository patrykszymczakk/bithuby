const express = require('express');
const router = express.Router();
const { register, activateAccount, login } = require('./authController');

// Trasa rejestracji
router.post('/register', register);

// Trasa aktywacji konta
router.get('/activate/:token', activateAccount);

// Trasa logowania
router.post('/login', login);



// Mockowe trasy (tylko do testów)
router.post('/mock-login', (req, res) => {
    const { username, password } = req.body;

    if (username === 'test' && password === 'test') {
        res.status(200).json({ message: 'Login successful', token: 'dummy-jwt-token' });
    } else {
        res.status(401).json({ message: 'Invalid credentials' });
    }
});

router.post('/mock-register', (req, res) => {
    const { username, password, email } = req.body;

    if (username && password && email) {
        res.status(201).json({ message: 'User registered successfully (mock).' });
    } else {
        res.status(400).json({ message: 'Invalid data in mock register.' });
    }
});

module.exports = router;
