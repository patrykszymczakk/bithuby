const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { sendActivationEmail } = require('../email');
const User = require('../models/User');

const JWT_SECRET = process.env.JWT_SECRET || '3H@rdT0Gu3$$+53cR3t#K3y!2024';

// Funkcja rejestracji użytkownika
const register = async (req, res) => {
    try {
        const { username, email, password } = req.body;

        // Sprawdzenie, czy użytkownik już istnieje
        const existingUser = await User.findByEmail(email);
        if (existingUser) {
            return res.status(400).json({ message: 'User already exists' });
        }

        // Hashowanie hasła
        const hashedPassword = await bcrypt.hash(password, 10);

        // Tworzenie nowego użytkownika w bazie danych
        const user = await User.create(username, email, hashedPassword);

        // Generowanie tokenu aktywacyjnego
        const token = jwt.sign({ userId: user.id, email }, JWT_SECRET, { expiresIn: '1d' });

        // Link aktywacyjny
        const activationLink = `http://localhost:3001/auth/activate/${token}`;

        // Wysyłanie e-maila aktywacyjnego
        await sendActivationEmail(email, activationLink);

        res.status(201).json({
            message: 'Registration successful. Please check your email to activate your account.',
        });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ message: 'Registration failed.', error });
    }
};

// Funkcja aktywacji konta
const activateAccount = async (req, res) => {
    try {
        const { token } = req.params;

        // Weryfikacja tokenu
        const decoded = jwt.verify(token, JWT_SECRET);

        // Znalezienie użytkownika na podstawie ID
        const user = await User.findById(decoded.userId);
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }

        if (user.isActive) {
            return res.status(400).json({ message: 'Account already activated.' });
        }

        // Aktywacja konta użytkownika
        await User.update(user.id, { isActive: true });

        // Przekierowanie do strony wyboru kraju i kategorii
        res.redirect('/select.html');
    } catch (error) {
        console.error('Activation error:', error);
        res.status(500).json({ message: 'Activation failed.', error });
    }
};

// Funkcja logowania
const login = async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await User.findByEmail(email);
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }

        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(401).json({ message: 'Invalid password.' });
        }

        if (!user.isActive) {
            return res.status(403).json({ message: 'Account is not activated. Please activate your account.' });
        }

        // Generowanie tokena JWT
        const token = jwt.sign(
            { userId: user.id, email: user.email, country: user.country, category: user.category },
            JWT_SECRET,
            { expiresIn: '1d' }
        );

        res.status(200).json({
            message: 'Login successful.',
            token,
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ message: 'Login failed.' });
    }
};



// Eksport funkcji
module.exports = {
    register, // Funkcja rejestracji
    activateAccount, // Funkcja aktywacji
    login, // Funkcja logowania
};
