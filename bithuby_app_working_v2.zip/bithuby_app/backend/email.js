const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    host: 'smtp.mailtrap.io',
    port: 587,
    auth: {
        user: '9f1867530ac067',
        pass: '36f187cd6c316b',
    },
});

exports.sendActivationEmail = async (to, activationLink) => {
    const mailOptions = {
        from: '"Your App" <no-reply@yourapp.com>',
        to,
        subject: 'Activate Your Account',
        html: `
            <h1>Welcome to Your App</h1>
            <p>Click the link below to activate your account:</p>
            <a href="${activationLink}">${activationLink}</a>
        `,
    };

    await transporter.sendMail(mailOptions);
};
